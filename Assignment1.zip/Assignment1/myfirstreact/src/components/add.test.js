import React from "react";
import ReactDOM from "react-dom";
import InputTodo from "./InputTodo";
import ListTodo from "./ListTodos";
import EditTodo from "./EditTodo";

import { isTSAnyKeyword, tsExternalModuleReference } from "@babel/types";

it("renders without crasing Add button", () => {
  const div = document.createElement("div");
  ReactDOM.render(<InputTodo></InputTodo>, div);
});

it("renders without crasing Delete button", () => {
  const div = document.createElement("div");
  ReactDOM.render(<ListTodo></ListTodo>, div);
});
