import React from "react";
import App from "../App";

export default {
  title: "name",
};

export const name = () => <textarea>Test textarea in story book</textarea>;

export const app = () => <App />;
